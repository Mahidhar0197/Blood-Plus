package com.example.satish.parsetry;

import android.app.Activity;

/**
 * Created by satish on 1/24/2015.
 */
public class PostActivity extends Activity {
}
