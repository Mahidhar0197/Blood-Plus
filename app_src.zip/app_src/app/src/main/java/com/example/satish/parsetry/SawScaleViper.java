package com.example.satish.parsetry;

/**
 * Created by satish on 1/26/2015.
 */
import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Mahidhar on 1/25/2015.
 */
public class SawScaleViper extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.saw);
    }
}
